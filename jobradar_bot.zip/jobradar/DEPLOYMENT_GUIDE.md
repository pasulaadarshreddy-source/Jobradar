# 🤖 JobRadar Bot — Deployment Guide for Adarsh
## Deploy in 15 minutes, runs 24/7 for FREE on Railway

---

## WHAT THIS BOT DOES
- Scans LinkedIn, Naukri, Internshala, Wellfound, Cutshort, Indeed every 30 minutes
- Matches jobs against YOUR resume (skills, location, experience level)
- Sends you a beautiful HTML email alert with full job details + match score
- Logs everything to Google Sheets automatically
- Skips companies that already rejected you
- Prioritises South India locations + low competition jobs

---

## STEP 1 — Get the code on GitHub (5 minutes)

1. Go to https://github.com and sign in (or create free account)
2. Click "New repository" → Name it "jobradar" → Private → Create
3. Click "uploading an existing file"
4. Upload these files from the ZIP:
   - job_scraper.py
   - requirements.txt
   - Procfile
   - railway.json
5. Click "Commit changes"

---

## STEP 2 — Get Gmail App Password (3 minutes)

⚠️ You CANNOT use your regular Gmail password. You need an App Password.

1. Go to: https://myaccount.google.com/security
2. Make sure 2-Step Verification is ON (turn it on if not)
3. Search for "App Passwords" in the search bar
4. Click App Passwords
5. Select "Mail" → "Other (Custom)" → Type "JobRadar" → Generate
6. Copy the 16-character password shown (example: abcd efgh ijkl mnop)
7. SAVE IT — you won't see it again

---

## STEP 3 — Deploy on Railway (5 minutes)

Railway gives you FREE hosting — no credit card needed for small bots.

1. Go to https://railway.app → Sign in with GitHub
2. Click "New Project" → "Deploy from GitHub repo"
3. Select your "jobradar" repository
4. Click "Add Variables" and add these one by one:

   Variable Name        | Value
   ---------------------|------------------------------------------
   GMAIL_ADDRESS        | pasula.adarshreddy@gmail.com
   GMAIL_APP_PASS       | (the 16-char password from Step 2)
   ALERT_EMAIL          | pasula.adarshreddy@gmail.com
   SCAN_INTERVAL        | 1800
   MIN_MATCH_SCORE      | 55

5. Click "Deploy" → Wait 2 minutes for build

6. Check the logs — you should see:
   "🤖 JobRadar Bot started for P. Adarsh Reddy"
   "🔍 Starting scan at ..."

---

## STEP 4 — Set up Google Sheets Tracker (Optional but recommended)

1. Go to: https://console.cloud.google.com
2. Create a new project called "JobRadar"
3. Enable "Google Sheets API" (search in APIs & Services)
4. Go to "Credentials" → Create Service Account
   - Name: jobradar-bot
   - Role: Editor
5. Click the service account → Keys tab → Add Key → JSON
6. Download the JSON file
7. Open it with Notepad, copy ALL the text
8. In Railway, add variable: SHEETS_CREDS = (paste the entire JSON)

9. Create a new Google Sheet at sheets.google.com
10. Name it "JobRadar Tracker"
11. Copy the Sheet ID from the URL:
    docs.google.com/spreadsheets/d/[THIS_IS_THE_ID]/edit
12. In Railway, add variable: SHEETS_ID = (paste the ID)
13. Go back to the JSON file, find "client_email" value
14. Share your Google Sheet with that email address (Editor access)

Done! Jobs will auto-log to your sheet.

---

## WHAT YOU'LL RECEIVE IN YOUR EMAIL

Every matching job will arrive with:
✅ Company name + exact role
✅ Your personal match score (%)
✅ Which of YOUR skills matched
✅ Number of applicants (low = apply fast!)
✅ Full job description
✅ Direct apply link
✅ Smart tip for that specific role
🔥 Special "LOW COMPETITION" flag when < 100 applicants

---

## ADJUSTING THE BOT

To change settings, update Railway environment variables:

| What to change       | Variable          | Example values    |
|----------------------|-------------------|-------------------|
| Scan frequency       | SCAN_INTERVAL     | 900=15min, 3600=1hr |
| Alert sensitivity    | MIN_MATCH_SCORE   | 40 (more), 70 (fewer) |
| Your email           | ALERT_EMAIL       | your@email.com    |

---

## TROUBLESHOOTING

❌ "Authentication failed" → Double-check GMAIL_APP_PASS (no spaces)
❌ No emails arriving → Check spam folder first
❌ Bot stopped → Railway free tier sleeps after ~500hrs/month — upgrade to $5/mo Hobby plan for unlimited
❌ Sheets not updating → Make sure sheet is shared with the service account email

---

## MONTHLY COST

- Railway free tier: $0 (500 hrs/month — enough for ~21 days)
- Railway Hobby: $5/month (unlimited — recommended once you have a job!)
- Gmail: Free
- Google Sheets: Free

Total: $0 to start, $5/month for 24/7 reliability

---

## SOURCES THE BOT SCANS

| Platform      | Type          | How accessed         |
|---------------|---------------|----------------------|
| Indeed India  | Job board     | RSS feed             |
| Naukri        | Job board     | Public API           |
| Internshala   | Fresher jobs  | Web scraping         |
| Wellfound     | Startup jobs  | Web scraping         |
| Cutshort      | Startup jobs  | Public API           |
| TimesJobs     | Job board     | RSS feed             |
| Shine         | Job board     | RSS feed             |

---

Good luck Adarsh! 🚀
The bot will work harder than any job portal's email alert system.
